package br.com.fiap.model;

import br.com.fiap.anotation.Tabela;

@Tabela(nome = "TAB_ALUNO")
public class Aluno {

}
