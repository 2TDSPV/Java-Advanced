package br.com.fiap.bean;

//Interface -> define as assinaturas dos metodos (contrato)
public interface ContaInvestimento {

	double calculaRetornoInvestimento();
	
}
