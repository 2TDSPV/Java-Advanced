package br.com.fiap.bean;

//Enum -> conjunto de constantes
public enum TipoConta {

	COMUM, ESPECIAL, PREMIUM;
	
}
