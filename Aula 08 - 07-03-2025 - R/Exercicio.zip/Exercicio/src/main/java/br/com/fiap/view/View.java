package br.com.fiap.view;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.GregorianCalendar;
import java.util.List;

import br.com.fiap.bean.ContaCorrente;
import br.com.fiap.bean.ContaPoupanca;
import br.com.fiap.bean.TipoConta;
import br.com.fiap.exception.SaldoInsuficienteException;

public class View {

    public static void main(String[] args) {
        //Instanciar uma conta corrente
        Calendar data = new GregorianCalendar(2024, Calendar.AUGUST, 8);
        ContaCorrente cc = new ContaCorrente(10050, 1234, data, 1000, TipoConta.COMUM);

        //Instanciar uma conta poupanca
        ContaPoupanca cp = new ContaPoupanca(20050,1234, Calendar.getInstance(), 100, 1);

        //Chamar o metodo retirar da conta corrente
        try {
            cc.retirar(10000);
            System.out.println("Saque realizado, saldo disponivel: " + cc.getSaldo());
        }catch(SaldoInsuficienteException e) {
            System.err.println(e.getMessage());
        }

        //Criar uma lista de conta corrente
        List<ContaCorrente> lista = new ArrayList<ContaCorrente>();

        //Adicionar 3 contas
        lista.add(cc);
        lista.add(new ContaCorrente(12000, 3124, data, 7500, TipoConta.ESPECIAL));
        lista.add(new ContaCorrente(51007, 2226, Calendar.getInstance(), 12000, TipoConta.PREMIUM));

        //Exibir os saldos dessas 3 contas
        for (ContaCorrente item : lista) {
            System.out.println(item.getSaldo());
        }

    }
}
