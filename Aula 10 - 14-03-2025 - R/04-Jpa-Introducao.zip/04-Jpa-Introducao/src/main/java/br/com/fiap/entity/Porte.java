package br.com.fiap.entity;

public enum Porte {

	PEQUENO, MEDIO, GRANDE
	
}
