package br.com.fiap.exception;

public class IdNaoEncontradoException extends Exception {

	public IdNaoEncontradoException(String message) {
		super(message);
	}
	
}