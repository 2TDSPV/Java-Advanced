package br.com.fiap.TranquiloCalmaa;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TranquiloCalmaaApplicationTests {

	@Test
	void contextLoads() {
	}

}
